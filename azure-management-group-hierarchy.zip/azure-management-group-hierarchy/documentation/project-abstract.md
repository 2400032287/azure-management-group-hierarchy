# Project Abstract

Azure Management Group Hierarchy Design provides a structured governance model for Azure resources. The design places subscriptions into management groups based on environments such as Production, Development, and Sandbox. Azure Policy and Azure RBAC are used to enforce organizational rules and control access. Security, monitoring, cost management, and resource protection are added as cross-cutting governance capabilities. The project demonstrates a scalable and manageable approach to Azure cloud governance.
