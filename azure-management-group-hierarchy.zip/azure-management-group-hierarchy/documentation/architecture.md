# Architecture

```text
Azure Tenant Root Group
|
+-- Production Management Group
|   +-- Production Subscription 01
|   +-- Production Subscription 02
|
+-- Development Management Group
|   +-- Development Subscription 01
|   +-- Development Subscription 02
|
+-- Sandbox Management Group
    +-- Sandbox Subscription 01

Cross-cutting governance:
Azure Policy | RBAC | Defender for Cloud | Azure Monitor
Cost Management | Resource Locks | Activity Log
```

Management groups provide the governance boundary. Subscriptions are grouped by environment, while policies and role assignments can be applied at the appropriate scope.
