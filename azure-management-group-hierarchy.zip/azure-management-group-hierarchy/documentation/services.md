# Azure Services Required

| Service | Purpose |
|---|---|
| Azure Management Groups | Organize subscriptions into a hierarchy |
| Azure Subscriptions | Isolate billing and resource environments |
| Azure Resource Groups | Organize resources |
| Azure Policy | Enforce governance and compliance |
| Microsoft Entra ID | Identity and authentication |
| Azure RBAC | Permission management |
| Microsoft Defender for Cloud | Security posture and protection |
| Azure Monitor | Metrics, logs, and monitoring |
| Azure Cost Management | Cost tracking and budgets |
| Resource Locks | Protect critical resources |
| Activity Log | Track management operations |
