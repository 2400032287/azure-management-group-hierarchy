// Example Bicep template for a management-group hierarchy.
// Replace names/IDs and validate permissions before deployment.

targetScope = 'tenant'

param rootManagementGroupName string = 'contoso-root'
param productionManagementGroupName string = 'production'
param developmentManagementGroupName string = 'development'
param sandboxManagementGroupName string = 'sandbox'

resource productionGroup 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: productionManagementGroupName
  properties: {
    displayName: 'Production'
  }
}

resource developmentGroup 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: developmentManagementGroupName
  properties: {
    displayName: 'Development'
  }
}

resource sandboxGroup 'Microsoft.Management/managementGroups@2023-04-01' = {
  name: sandboxManagementGroupName
  properties: {
    displayName: 'Sandbox'
  }
}

// Child management groups can be placed under a parent management group
// using Microsoft.Management/managementGroups resources with the appropriate
// parent scope and permissions. Validate against your tenant structure.
