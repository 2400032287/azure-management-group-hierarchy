# Screenshots

Place Azure Portal screenshots here after implementing the project.

Suggested screenshots:
1. Management Group hierarchy
2. Subscriptions under each group
3. Azure Policy assignment
4. RBAC role assignment
5. Cost Management dashboard
6. Azure Monitor dashboard
7. Defender for Cloud overview
