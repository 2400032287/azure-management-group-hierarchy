# Azure Management Group Hierarchy Design

## Abstract
Azure Management Group Hierarchy Design is a cloud governance project that organizes Azure subscriptions into a structured hierarchy. It helps organizations manage policies, access control, security, compliance, and costs from a central location.

## Architecture
Tenant Root Group
- Production Management Group
  - Production Subscription 01
  - Production Subscription 02
- Development Management Group
  - Development Subscription 01
  - Development Subscription 02
- Sandbox Management Group
  - Sandbox Subscription 01

Governance is applied using Azure Policy, Microsoft Entra ID/RBAC, Microsoft Defender for Cloud, Azure Monitor, Cost Management, and Resource Locks.

## Services Used
- Azure Management Groups
- Azure Subscriptions
- Azure Resource Groups
- Azure Policy
- Microsoft Entra ID
- Azure RBAC
- Microsoft Defender for Cloud
- Azure Monitor
- Azure Cost Management
- Azure Resource Locks
- Azure Activity Log

## Repository Structure
```text
azure-management-group-hierarchy/
├── README.md
├── architecture/
│   └── architecture-diagram.txt
├── policies/
│   ├── allowed-locations.json
│   ├── required-tags.json
│   └── security-policy.json
├── infrastructure/
│   └── management-groups.bicep
├── documentation/
│   ├── project-abstract.md
│   ├── architecture.md
│   └── services.md
└── screenshots/
    └── README.md
```

## Project Workflow
1. Create management groups.
2. Organize subscriptions.
3. Create resource groups.
4. Apply Azure Policies.
5. Configure RBAC.
6. Enable monitoring and security.
7. Configure budgets and cost controls.
8. Test governance rules.
9. Document results and screenshots.

## GitHub
Upload this folder to a new GitHub repository named `azure-management-group-hierarchy`.
